module.exports = {
    keyboard: {
        reply_markup: {
            keyboard: [
            [{ text: '📅 Harian' }],
            [{ text: '📆 Mingguan' }],
            [{ text: '🗓 Bulanan' }],
            [{ text: '📘 Tahunan' }],
            [{ text: '⬅️ Kembali' }]
        ],
        resize_keyboard: true
        }
    }
};