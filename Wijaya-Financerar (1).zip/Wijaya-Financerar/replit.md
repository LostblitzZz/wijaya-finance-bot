# Wijaya Finance Bot

Bot Telegram untuk pencatatan keuangan pribadi dengan fitur laporan Excel dan PDF.

## Overview
- **Tipe**: Telegram Bot (Webhook Mode)
- **Framework**: Node.js + Express
- **Database**: PostgreSQL
- **Port**: 5000

## Fitur
- Tambah pemasukan
- Tambah pengeluaran
- Lihat laporan (harian, mingguan, bulanan, tahunan)
- Export laporan ke Excel dan PDF

## Struktur Proyek
```
├── index.js          # Entry point - Webhook server
├── bot.js            # Bot logic handler
├── db.js             # Database connection
├── package.json      # Dependencies
├── menus/            # Keyboard menus
│   ├── mainMenu.js
│   ├── expenseMenu.js
│   ├── incomeMenu.js
│   ├── reportMenu.js
│   └── periodMenu.js
├── utils/            # Utilities
│   ├── state.js      # User state management
│   ├── format.js     # Currency formatting
│   ├── reportExcel.js
│   └── reportPDF.js
└── reports/          # Generated reports
```

## Environment Variables
- `BOT_TOKEN` - Token dari BotFather
- `DATABASE_URL` - PostgreSQL connection string

## Database Schema
Tabel `transactions`:
- user_id (bigint) - Telegram chat ID
- tipe (varchar) - 'masuk' atau 'keluar'
- item (varchar) - Nama item
- harga (integer) - Nominal
- tanggal (timestamp) - Waktu transaksi

## Deployment
Bot menggunakan webhook mode sehingga bisa online 24/7 tanpa perlu laptop menyala.
Webhook otomatis diset saat server start menggunakan REPLIT_DEV_DOMAIN.
