module.exports = {
    askItem: 'Masukkan sumber pemasukan:',
    askPrice: 'Masukkan nominal pemasukan:'
};