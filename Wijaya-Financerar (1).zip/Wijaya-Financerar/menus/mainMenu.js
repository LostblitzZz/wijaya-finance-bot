module.exports = {
    keyboard: {
        reply_markup: {
            keyboard: [
                [{ text: '➕ Tambah Pemasukan' }],
                [{ text: '➖ Tambah Pengeluaran' }],
                [{ text: '📊 Lihat Laporan' }]
            ],
            resize_keyboard: true
        }
    }
};