module.exports = {
    askItem: 'Masukkan nama pengeluaran:',
    askPrice: 'Masukkan nominal pengeluaran:'
};